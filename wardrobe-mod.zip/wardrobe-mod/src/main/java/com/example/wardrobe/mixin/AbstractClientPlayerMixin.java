package com.example.wardrobe.mixin;

import com.example.wardrobe.skin.SkinManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Swaps in a wardrobe skin's texture when the local player asks for its own
 * skin textures, so both the pause-screen preview and the actual in-world
 * render pick it up. This is a purely client-side cosmetic override: it does
 * not touch your Mojang account skin, so players without this mod (or with
 * it but no matching resource) will keep seeing your normal skin.
 *
 * <p><b>Version note:</b> Minecraft's skin-texture record (originally
 * {@code SkinTextures} with texture/textureUrl/capeTexture/elytraTexture/
 * model/secure components) was reworked around 1.21.9 into a differently
 * shaped {@code PlayerSkin} record built from {@code ClientAsset.Texture}
 * values. If your decompiled sources show a different record shape than the
 * one used below, update the constructor call to match - your IDE's error
 * messages will point at exactly which accessor names changed.</p>
 */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerMixin {

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void wardrobe$overrideSkin(CallbackInfoReturnable<SkinTextures> cir) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) return;

        Identifier override = SkinManager.getInstance().getSelectedTextureIdOrNull();
        if (override == null) return;

        SkinTextures original = cir.getReturnValue();
        SkinTextures replaced = new SkinTextures(
                override,
                null,
                original.capeTexture(),
                original.elytraTexture(),
                original.model(),
                original.secure()
        );
        cir.setReturnValue(replaced);
    }
}
