package com.example.wardrobe.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;

/**
 * Draws the client player's 3D model inside a rectangular panel, letting the
 * given {@link PreviewRotation} fully control the facing direction instead of
 * the vanilla "look at the cursor" behaviour.
 */
public final class PlayerPreviewRenderer {

    private PlayerPreviewRenderer() {}

    public static void render(DrawContext context, int x1, int y1, int x2, int y2, int scale, PreviewRotation rotation) {
        MinecraftClient client = MinecraftClient.getInstance();
        AbstractClientPlayerEntity player = client.player;
        if (player == null) return;

        int centerX = (x1 + x2) / 2;
        int bottomY = y2;

        // Remember the entity's real orientation so we can restore it after
        // rendering - we are temporarily repurposing the live player entity
        // as our preview "doll", and must not leave it rotated for the
        // actual game frame that follows.
        float origYaw = player.getYaw();
        float origPrevYaw = player.prevYaw;
        float origPitch = player.getPitch();
        float origPrevPitch = player.prevPitch;
        float origBodyYaw = player.bodyYaw;
        float origPrevBodyYaw = player.prevBodyYaw;
        float origHeadYaw = player.headYaw;
        float origPrevHeadYaw = player.prevHeadYaw;

        float yaw = rotation.getYaw();
        float pitch = rotation.getPitch();

        player.setYaw(yaw);
        player.prevYaw = yaw;
        player.bodyYaw = yaw;
        player.prevBodyYaw = yaw;
        player.headYaw = yaw;
        player.prevHeadYaw = yaw;
        player.setPitch(-pitch);
        player.prevPitch = -pitch;

        // Passing the panel's own center as the "mouse" position disables
        // vanilla's extra cursor-follow head turn, since our rotation state
        // already fully drives the pose.
        InventoryScreen.renderEntityInInventory(
                context, x1, y1, x2, y2, scale, 1.0f, centerX, bottomY, player
        );

        player.setYaw(origYaw);
        player.prevYaw = origPrevYaw;
        player.setPitch(origPitch);
        player.prevPitch = origPrevPitch;
        player.bodyYaw = origBodyYaw;
        player.prevBodyYaw = origPrevBodyYaw;
        player.headYaw = origHeadYaw;
        player.prevHeadYaw = origPrevHeadYaw;
    }
}
