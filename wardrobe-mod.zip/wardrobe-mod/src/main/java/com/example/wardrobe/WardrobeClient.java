package com.example.wardrobe;

import com.example.wardrobe.skin.SkinManager;
import net.fabricmc.api.ClientModInitializer;

/**
 * Client entrypoint. Loads the saved wardrobe (list of imported skins +
 * whichever one is currently selected) as soon as the game starts.
 */
public class WardrobeClient implements ClientModInitializer {

    public static final String MOD_ID = "wardrobe";

    @Override
    public void onInitializeClient() {
        SkinManager.getInstance().load();
    }
}
