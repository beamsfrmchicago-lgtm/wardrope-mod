package com.example.wardrobe.skin;

import net.minecraft.util.Identifier;

/**
 * One skin the player has imported into the wardrobe.
 *
 * @param id        stable unique id (also used as the file name on disk, no extension)
 * @param name      display name shown in the wardrobe screen
 * @param slimModel true if this skin uses the slim ("Alex") arm model
 */
public record SkinEntry(String id, String name, boolean slimModel) {

    /** The identifier this skin's texture is registered under with the texture manager. */
    public Identifier textureId() {
        return Identifier.of("wardrobe", "skin/" + id.toLowerCase());
    }

    public String fileName() {
        return id + ".png";
    }
}
