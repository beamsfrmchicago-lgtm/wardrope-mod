package com.example.wardrobe.gui;

import com.example.wardrobe.skin.SkinEntry;
import com.example.wardrobe.skin.SkinManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.nio.file.Path;

/**
 * The wardrobe: a 3D preview on the left (drag to spin it a full 360) and a
 * list of imported skins on the right. Selecting an entry makes it the active
 * client-side skin; "Import Skin..." opens a native file picker for a PNG.
 */
public class WardrobeScreen extends Screen {

    private final Screen parent;
    private final PreviewRotation rotation = new PreviewRotation();
    private final SkinManager skinManager = SkinManager.getInstance();

    private int previewX1, previewY1, previewX2, previewY2;
    private int listX, listY;

    public WardrobeScreen(Screen parent) {
        super(Text.literal("Wardrobe"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        previewX1 = 20;
        previewY1 = 30;
        previewX2 = previewX1 + 110;
        previewY2 = this.height - 50;

        listX = previewX2 + 30;
        listY = 40;

        rebuildList();
    }

    /** Clears and re-adds one row of widgets per saved skin. Call after any add/remove/select. */
    private void rebuildList() {
        // Remove previously added per-skin widgets by fully re-running init.
        this.clearChildren();

        int y = listY;
        for (SkinEntry entry : skinManager.getSkins()) {
            boolean selected = skinManager.getSelected().map(s -> s.id().equals(entry.id())).orElse(false);

            ButtonWidget selectButton = ButtonWidget.builder(
                            Text.literal((selected ? "> " : "") + entry.name()),
                            b -> {
                                skinManager.select(selected ? null : entry);
                                rebuildList();
                            })
                    .dimensions(listX, y, 160, 20)
                    .build();
            this.addDrawableChild(selectButton);

            ButtonWidget deleteButton = ButtonWidget.builder(Text.literal("X"), b -> {
                        skinManager.removeSkin(entry);
                        rebuildList();
                    })
                    .dimensions(listX + 166, y, 20, 20)
                    .build();
            this.addDrawableChild(deleteButton);

            y += 24;
        }

        // Re-add the buttons that are always present. init() adds them once
        // normally; on rebuilds triggered from a click we re-create them too
        // since clearChildren() just wiped everything.
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Import Skin..."), b -> importSkin())
                .dimensions(previewX1, previewY2 + 10, 110, 20)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b ->
                        MinecraftClient.getInstance().setScreen(parent))
                .dimensions(this.width - 90, this.height - 30, 70, 20)
                .build());
    }

    private void importSkin() {
        // Native file dialogs block the calling thread, so run this off the
        // render thread and hop back with client.execute(...) once it returns.
        new Thread(() -> {
            String path;
            try (MemoryStack stack = MemoryStack.stackPush()) {
                PointerBuffer filters = stack.mallocPointer(1);
                filters.put(stack.UTF8("*.png"));
                filters.flip();
                path = TinyFileDialogs.tinyfd_openFileDialog("Select a skin PNG", null, filters, "PNG images", false);
            }

            if (path == null) return;
            Path selected = Path.of(path);
            String displayName = selected.getFileName().toString().replaceFirst("\\.png$", "");

            MinecraftClient.getInstance().execute(() -> {
                try {
                    skinManager.importSkin(selected, displayName);
                    rebuildList();
                } catch (Exception e) {
                    System.err.println("[wardrobe] Failed to import skin: " + e.getMessage());
                }
            });
        }, "wardrobe-file-picker").start();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);

        PlayerPreviewRenderer.render(context, previewX1, previewY1, previewX2, previewY2, 35, rotation);

        if (skinManager.getSkins().isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("No skins yet - import one below."), listX, listY, 0xAAAAAA);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && rotation.isMouseOver(mouseX, mouseY, previewX1, previewY1, previewX2, previewY2)) {
            rotation.beginDrag();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (rotation.isDragging()) {
            rotation.drag(deltaX, deltaY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (rotation.isDragging()) {
            rotation.endDrag();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPauseGame() {
        return true;
    }
}
