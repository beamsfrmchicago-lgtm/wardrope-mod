package com.example.wardrobe.mixin;

import com.example.wardrobe.gui.PlayerPreviewRenderer;
import com.example.wardrobe.gui.PreviewRotation;
import com.example.wardrobe.gui.WardrobeScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds a rotating 3D player preview + a "Wardrobe" button to the left side of
 * the pause (escape) menu.
 *
 * <p>The mixin class extends {@link Screen} (GameMenuScreen's real
 * superclass) purely so that {@code super.mouseClicked(...)} etc. below
 * compile and get rewritten by Mixin to call Screen's real implementation on
 * the target instance. The constructor is never actually used at runtime -
 * Mixin strips it - it only needs to exist so this file compiles.</p>
 *
 * <p><b>Version note:</b> {@code initWidgets} is the private method
 * GameMenuScreen currently uses to lay out its buttons. If Mixin fails to
 * find it on your exact build, open GameMenuScreen in your IDE (with the
 * Minecraft Development plugin's Mixin support), find whichever method
 * creates the "Back to Game" / "Save and Quit" buttons, and use its "Copy
 * target reference" action to fix the string below.</p>
 */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {

    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Shadow public int width;
    @Shadow public int height;

    private final PreviewRotation wardrobe$rotation = new PreviewRotation();
    private int wardrobe$panelX1, wardrobe$panelY1, wardrobe$panelX2, wardrobe$panelY2;

    @Inject(method = "initWidgets", at = @At("TAIL"))
    private void wardrobe$addButton(CallbackInfo ci) {
        int panelWidth = 90;
        int panelHeight = 110;
        wardrobe$panelX1 = 12;
        wardrobe$panelY1 = (this.height - panelHeight) / 2 - 20;
        wardrobe$panelX2 = wardrobe$panelX1 + panelWidth;
        wardrobe$panelY2 = wardrobe$panelY1 + panelHeight;

        GameMenuScreen self = (GameMenuScreen) (Object) this;
        ButtonWidget wardrobeButton = ButtonWidget.builder(Text.literal("Wardrobe"), button ->
                        MinecraftClient.getInstance().setScreen(new WardrobeScreen(self)))
                .dimensions(wardrobe$panelX1, wardrobe$panelY2 + 6, panelWidth, 20)
                .build();

        this.addDrawableChild(wardrobeButton);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void wardrobe$renderPreview(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        PlayerPreviewRenderer.render(context, wardrobe$panelX1, wardrobe$panelY1, wardrobe$panelX2, wardrobe$panelY2, 30, wardrobe$rotation);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && wardrobe$rotation.isMouseOver(mouseX, mouseY, wardrobe$panelX1, wardrobe$panelY1, wardrobe$panelX2, wardrobe$panelY2)) {
            wardrobe$rotation.beginDrag();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (wardrobe$rotation.isDragging()) {
            wardrobe$rotation.drag(deltaX, deltaY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (wardrobe$rotation.isDragging()) {
            wardrobe$rotation.endDrag();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }
}
