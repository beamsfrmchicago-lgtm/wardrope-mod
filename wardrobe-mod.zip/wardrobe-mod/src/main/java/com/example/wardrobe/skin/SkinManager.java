package com.example.wardrobe.skin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Loads, stores, and applies the player's local "wardrobe" of custom skins.
 *
 * <p>Everything here is purely client-side cosmetics: skins are stored as PNG
 * files under {@code .minecraft/config/wardrobe/skins/}, described in
 * {@code wardrobe.json}, and swapped in by overriding the texture the local
 * player renders with (see {@code AbstractClientPlayerMixin}). This does NOT
 * change your real Mojang account skin - other players without this mod will
 * still see your normal skin.</p>
 */
public final class SkinManager {

    private static final SkinManager INSTANCE = new SkinManager();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final List<SkinEntry> skins = new ArrayList<>();
    private String selectedId = null;
    private boolean loaded = false;

    private SkinManager() {}

    public static SkinManager getInstance() {
        return INSTANCE;
    }

    // ---------------------------------------------------------------- paths

    private Path rootDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("wardrobe");
    }

    private Path skinsDir() {
        return rootDir().resolve("skins");
    }

    private Path manifestFile() {
        return rootDir().resolve("wardrobe.json");
    }

    // ------------------------------------------------------------ load/save

    public void load() {
        if (loaded) return;
        loaded = true;
        try {
            Files.createDirectories(skinsDir());
        } catch (IOException e) {
            throw new RuntimeException("Could not create wardrobe folder", e);
        }

        Path manifest = manifestFile();
        if (!Files.exists(manifest)) {
            save();
            return;
        }

        try (Reader reader = Files.newBufferedReader(manifest, StandardCharsets.UTF_8)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;

            skins.clear();
            JsonArray array = root.getAsJsonArray("skins");
            if (array != null) {
                for (var element : array) {
                    JsonObject obj = element.getAsJsonObject();
                    String id = obj.get("id").getAsString();
                    String name = obj.get("name").getAsString();
                    boolean slim = obj.has("slim") && obj.get("slim").getAsBoolean();
                    skins.add(new SkinEntry(id, name, slim));
                }
            }

            selectedId = root.has("selected") && !root.get("selected").isJsonNull()
                    ? root.get("selected").getAsString()
                    : null;

            // Register a texture for every skin we know about.
            for (SkinEntry entry : skins) {
                registerTexture(entry);
            }
        } catch (IOException e) {
            System.err.println("[wardrobe] Failed to read wardrobe.json: " + e.getMessage());
        }
    }

    public void save() {
        JsonObject root = new JsonObject();
        JsonArray array = new JsonArray();
        for (SkinEntry entry : skins) {
            JsonObject obj = new JsonObject();
            obj.addProperty("id", entry.id());
            obj.addProperty("name", entry.name());
            obj.addProperty("slim", entry.slimModel());
            array.add(obj);
        }
        root.add("skins", array);
        root.addProperty("selected", selectedId);

        try {
            Files.createDirectories(rootDir());
            try (Writer writer = Files.newBufferedWriter(manifestFile(), StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
        } catch (IOException e) {
            System.err.println("[wardrobe] Failed to write wardrobe.json: " + e.getMessage());
        }
    }

    // -------------------------------------------------------------- editing

    /**
     * Copies an external PNG into the wardrobe folder, registers its texture,
     * and adds it to the list. Call this from the "Import" button.
     */
    public SkinEntry importSkin(Path sourcePng, String displayName) throws IOException {
        String id = UUID.randomUUID().toString().substring(0, 8);
        boolean slim = detectSlimModel(sourcePng);
        SkinEntry entry = new SkinEntry(id, displayName, slim);

        Files.createDirectories(skinsDir());
        Files.copy(sourcePng, skinsDir().resolve(entry.fileName()), StandardCopyOption.REPLACE_EXISTING);

        registerTexture(entry);
        skins.add(entry);
        save();
        return entry;
    }

    public void removeSkin(SkinEntry entry) {
        skins.remove(entry);
        if (entry.id().equals(selectedId)) {
            selectedId = null;
        }
        try {
            Files.deleteIfExists(skinsDir().resolve(entry.fileName()));
        } catch (IOException e) {
            System.err.println("[wardrobe] Failed to delete skin file: " + e.getMessage());
        }
        MinecraftClient.getInstance().getTextureManager().destroyTexture(entry.textureId());
        save();
    }

    public void select(SkinEntry entry) {
        selectedId = entry == null ? null : entry.id();
        save();
    }

    public List<SkinEntry> getSkins() {
        return List.copyOf(skins);
    }

    public Optional<SkinEntry> getSelected() {
        return skins.stream().filter(s -> s.id().equals(selectedId)).findFirst();
    }

    // -------------------------------------------------------------- helpers

    private void registerTexture(SkinEntry entry) {
        Path file = skinsDir().resolve(entry.fileName());
        if (!Files.exists(file)) return;

        try (InputStream in = Files.newInputStream(file)) {
            NativeImage image = NativeImage.read(in);
            MinecraftClient.getInstance().execute(() ->
                    MinecraftClient.getInstance().getTextureManager()
                            .registerTexture(entry.textureId(), new NativeImageBackedTexture(entry::name, image))
            );
        } catch (IOException e) {
            System.err.println("[wardrobe] Failed to load skin texture " + entry.name() + ": " + e.getMessage());
        }
    }

    /**
     * Very small heuristic used by every skin viewer: on a 64x64 skin, the
     * pixel column at x=54,y=20 is part of the right-arm overlay that only
     * exists (non-transparent) on the wide "classic" model. If it's fully
     * transparent the skin is the slim "Alex" model.
     */
    private boolean detectSlimModel(Path pngFile) throws IOException {
        try (InputStream in = Files.newInputStream(pngFile)) {
            NativeImage image = NativeImage.read(in);
            try {
                if (image.getWidth() < 64 || image.getHeight() < 32) return false;
                int argb = image.getColor(54, 20);
                int alpha = (argb >> 24) & 0xFF;
                return alpha == 0;
            } finally {
                image.close();
            }
        }
    }

    public Identifier getSelectedTextureIdOrNull() {
        return getSelected().map(SkinEntry::textureId).orElse(null);
    }
}
