package com.example.wardrobe.gui;

import net.minecraft.client.util.math.MatrixStack;

/**
 * Tracks a free-spinning yaw + a clamped pitch for a 3D player preview panel,
 * driven by click-and-drag mouse input. One instance per preview panel.
 */
public class PreviewRotation {

    private static final float DEGREES_PER_PIXEL = 0.6f;
    private static final float MAX_PITCH = 35f;

    /** Full 360 degree horizontal spin, wraps around freely. */
    private float yaw = 0f;
    /** Vertical tilt, clamped so the model never flips upside down. */
    private float pitch = 10f;

    private boolean dragging = false;

    public boolean isMouseOver(double mouseX, double mouseY, int x1, int y1, int x2, int y2) {
        return mouseX >= x1 && mouseX <= x2 && mouseY >= y1 && mouseY <= y2;
    }

    public void beginDrag() {
        dragging = true;
    }

    public void endDrag() {
        dragging = false;
    }

    public boolean isDragging() {
        return dragging;
    }

    /** Call from the screen's mouseDragged with the raw per-frame delta. */
    public void drag(double deltaX, double deltaY) {
        yaw = (yaw + (float) deltaX * DEGREES_PER_PIXEL) % 360f;
        pitch = clamp(pitch - (float) deltaY * DEGREES_PER_PIXEL, -MAX_PITCH, MAX_PITCH);
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
